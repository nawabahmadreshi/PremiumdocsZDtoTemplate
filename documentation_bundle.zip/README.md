# Aquera Identity Survey Hub - User Guide

This bundle contains the premium, high-fidelity HTML offline documentation guide synced from Zendesk.

## 📦 What's Inside
- **`Identity_Survey_Hub_User_Guide.html`**: The interactive styled documentation viewer. Open this file in any web browser.
- **`images/`**: A folder containing all screenshots, diagrams, and inline assets used within the user guide.
- **`broken_links_report.txt`** *(Optional)*: If present, lists any broken links/missing articles found during the sync process.

## 🚀 How to View the Guide
1. **Double-click** `Identity_Survey_Hub_User_Guide.html` to open it in your browser (Chrome, Safari, Edge, Firefox, etc.).
2. Use the left **Table of Contents (TOC) sidebar** to jump directly to sections and sub-sections.
3. You can toggle/collapse the TOC sidebar via the arrow buttons at the sides to expand the main reader layout.

## 🖨️ Printing or Saving as PDF
- If you need to print or save a section, simply press `Cmd + P` (macOS) or `Ctrl + P` (Windows). The document uses a highly optimized print layout.
